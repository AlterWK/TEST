local skynet = require("skynet")
local skynet_call = skynet.call
local class_helper = require("helper.class_helper")
local moritx_user = class_helper.class("moritx_user")

function moritx_user:new(...)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o:init(...)
    return o
end

function moritx_user:init(game, data)
    self._game = game
    self._level = data.moritx_user_level
    self._exp = data.moritx_user_exp
    self._fuel = data.moritx_user_fuel
end

function moritx_user:start()
    --update fuel
end

function moritx_user:stop()

end

function moritx_user:add_exp(exp)
    self._exp = self._exp + exp
    --level up
end

function moritx_user:update_during_fuel(during_time)

end

function moritx_user:get_data_table()
    local t = {
        moritx_user_level = self._level,
        moritx_user_exp = self._exp,
        moritx_user_fuel = self._fuel,
    }
    return t
end

return moritx_user