local utility = {}

function utility.handler(obj, method)
    return function(...)
        return method(obj, ...)
    end
end

return utility