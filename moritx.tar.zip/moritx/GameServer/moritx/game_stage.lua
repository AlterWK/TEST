local skynet = require("skynet")
local skynet_call = skynet.call
local class_helper = require("helper.class_helper")
local stage_level = require("moritx.stage_level")
local game_stage = class_helper.class("game_stage")

function game_stage:new(...)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o:init(...)
    return o
end

function game_stage:init(game, data)
    self._game = game
    self._index = data.index
    --config
    self._cur_level = 0
    self._max_level = 24

    self._levels = {}
    if data.levels then
        for i = 1, #data.levels do
            local level = stage_level:new(data.levels[i])
            table.insert(self._levels, level)
        end
        self._cur_level = #self._levels
    else
        self:enter_next_level()
    end
end

function game_stage:get_cur_level()
    return self._levels[self._cur_level]
end

function game_stage:start_cur_level()
    self._levels[self._cur_level]:start()
end

function game_stage:finish_cur_level()
    self._levels[self._cur_level]:stop()
end

function game_stage:is_stage_finish()
    return self._cur_level >= self._max_level
end

function game_stage:enter_next_level()
    if self:is_stage_finish() then
        return
    end

    self._cur_level = self._cur_level + 1
    local data = {
        index = self._cur_level,
    }
    local next_level = stage_level:new(data)
    table.insert(self._levels, next_level)
end

function game_stage:get_data_table()
    local t = {
        index = self._index,
    }
    return t
end

return game_stage