local skynet = require("skynet")
local skynet_call = skynet.call
local class_helper = require("helper.class_helper")
local stage_level = class_helper.class("stage_level")

function stage_level:new(...)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o:init(...)
    return o
end

function stage_level:init(data)
    self._index = data.index
    self._reward_loots = data.reward_loots or self:get_reward_loots()
    self._reward_mods = data.reward_mods or self:get_reward_mods()
    self._finish_time = 0
end

function stage_level:get_reward_loots()
    --config
    local t = {}
    return t
end

function stage_level:get_reward_mods()
    --config
    local t = {}
    return t
end

function stage_level:start()
    if self._is_start then
        return
    end

    self._is_start = true
    self._finish_time = 0

    skynet.fork(function()
        while self._is_start do
            skynet.sleep(100)
            self._finish_time = self._finish_time + 1
        end
    end)
end

function stage_level:stop()
    self._is_start = false
end

function stage_level:get_data_table()
    local t = {
        index = self._index,
        finish_time = self._finish_time,
    }
    -- if #self._reward_loots > 0 then
    --     t._reward_loots = self._reward_loots
    -- end

    -- if #self._reward_mods > 0 then
    --     t.reward_mods = self._reward_mods
    -- end

    return t
end

return stage_level