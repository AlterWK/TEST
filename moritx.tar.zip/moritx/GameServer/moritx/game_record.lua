local skynet = require("skynet")
require("skynet.manager")
local kafka = require("kafka")
local cjson = require("cjson")
local game_record = {}

function game_record:new(...)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o:init(...)
    return o
end

function game_record:init(game)
    self._game = game

    local k = skynet.uniqueservice("kafka")
    skynet.name(".kafka", k)
end

function game_record:log_sensor(id, event, properties)
    local t = {
        distinct_id = id, -- 用户id，必填，也可以使用distinct_id，但是distinct_id和user_id不能共存
        time = skynet.time(), --时间戳，毫秒
        type = "track", -- 必填，固定值
        event = event, --事件名称，必填，大驼峰
        project = "k7game", -- 神策项目，必填，生产环境为k7game，开发环境为default
        send_to_sensors = true, -- 是否发送到神策，缺失的话，默认发送神策
        properties = properties
    }
    local msg = cjson.encode(t)
    assert(kafka.log_sensor(msg, 0))
end

return game_record