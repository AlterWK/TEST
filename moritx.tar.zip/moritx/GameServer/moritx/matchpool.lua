local class_helper = require("helper.class_helper")
local matchpool_full_players = require("match.matchpool_full_players")
local game_id, st_id = ...
game_id = tonumber(game_id)
st_id = tonumber(st_id)
local player_count
if st_id == 0 then
    player_count = 1
else 
    INFO("matchpool don't support st: " .. st_id)
    return
end
class_helper.newservice(matchpool_full_players, game_id, st_id, player_count)