local skynet = require("skynet")
local cjson = require("cjson")
local class_helper = require("helper.class_helper")
local game_record = require("moritx.game_record")
local moritx_user = require("moritx.moritx_user")
local role = require("moritx.role")
local game_stage = require("moritx.game_stage")
local game = class_helper.class("game", require("gamebase"))
local score_type = require("def").score_type
local utility = require("moritx.utility")
local shopconfig = require('moritx.config.shopconfig')
local treasure_controller = require('moritx.treasure_controller')
local treasureconfig = require("moritx.config.treasureconfig")

local INFO = INFO

function game:init_data(game_id, st_id, sproto_id, password, users)
    self.super:init_data(game_id, st_id, sproto_id, password, users)
    self._score_type = score_type.hb
    self._room_id = 2340
end

function game:init_handlers()
    self.super:init_handlers()

    --hall
    self._handlers["get_hall_scene"] = function()
        local hall_scene = {
            player = {},
            is_combat = self._is_combat,
            best_history = self._best_history,
        }

        hall_scene.player = {
            uid = self._player:get_id(),
            nickname = self._player:get_nickname(),
            hb = self._player:get_hb(),
            kb = self._player:get_kb(),
            wealth = self._player:get_wealth(),
            level = self._moritx_user._level,
            exp = self._moritx_user._exp,
            fuel = self._moritx_user._fuel,
        }

        self:send_to_all("hall_scene", hall_scene)
    end

    self._handlers["update_moritx_user"] = function()
        local t = {
            player = {
                uid = self._player:get_id(),
                nickname = self._player:get_nickname(),
                hb = self._player:get_hb(),
                kb = self._player:get_kb(),
                level = self._moritx_user._level,
                exp = self._moritx_user._exp,
                fuel = self._moritx_user._fuel,
            }
        }
        self:send_to_all("update_moritx_user", t)
    end

    self._handlers["enter_game_scene"] = function(chairid, args)
        local stage_index = args.stage_index
        if not stage_index then
            return
        end

        if not self._is_combat then
            -- update moritx user
            self._is_combat = true
            local stage_t = {
                index = stage_index,
                levels = {},
            }
            self._game_stage = game_stage:new(self._game_handle, stage_t)
            self._game_stage:enter_next_level()
            self._game_stage:start_cur_level()
            INFO("new_cur_level", self._game_stage._cur_level)
        end

        local t = {
            game_stage = {},
            stage_levels = {},
        }
        t.game_stage = self._game_stage:get_data_table()
        for i = 1, #self._game_stage._levels do
            t.stage_levels[i] = self._game_stage._levels[i]:get_data_table()
        end
        INFO("first_cur_level", self._game_stage._cur_level)
        if self._role then
            t.role = self._role:get_data_table()
        end
        self:send_to_all("enter_game_scene", t)
    end

    self._handlers["left_game"] = function()
        self:game_end()
        self._player:left_game()
    end

    --game
    self._handlers["get_game_scene"] = function()
        local game_scene = {
            player = {},
            role = {},
        }

        game_scene.player = {
            uid = self._player:get_id(),
            nickname = self._player:get_nickname(),
            hb = self._player:get_hb(),
            kb = self._player:get_kb(),
            level = self._moritx_user._level,
            exp = self._moritx_user._exp,
            fuel = self._moritx_user._fuel,
        }
        self._game_stage:start_cur_level()
        self:send_to_all("game_scene", game_scene)
    end

    self._handlers["enter_next_stage_level"] = function(chairid, args)
        local role_data = args.role
        if not (self._game_stage and role_data) then
            return
        end
        INFO("role_health",role_data.cur_health)
        if self._role then
            INFO("update_role")
            self._role:update_cur_state(role_data)
        else
            INFO("new role")
            self._role = role:new(self._game_handle, role_data)
        end
        --check add mods
        --check add loots
        self._role:add_mods(role_data.add_mods)
        self._role:add_loots(role_data.add_loots)

        if self._game_stage:is_stage_finish() then
            self._handlers["exit_game_scene"]()
        else
            self._game_stage:finish_cur_level()
            self._game_stage:enter_next_level()
            self._game_stage:start_cur_level()
            local t = {
                stage_level = self._game_stage:get_cur_level():get_data_table()
            }
            INFO('next_level', self._game_stage._cur_level)
            self:send_to_all("enter_stage_level", t)
        end
    end

    self._handlers["exit_game_scene"] = function()
        if not self._game_stage then
            return
        end
        self._game_stage:finish_cur_level()
        self:update_best_history(self._game_stage._cur_level)
        local t = {
            best_history = self._best_history,
            level_index = self._game_stage._cur_level,
        }
        if self._role then
            t.role = self._role:get_data_table()
        end
        self._game_stage = nil
        self._role = nil
        self._is_combat = false
        self:send_to_all("exit_game_scene", t)
    end

    self._handlers["buy_mall_items"] = utility.handler(self, self.buy_mall_items)
    self._handlers["open_treasure_box"] = utility.handler(self, self.open_treasure_box)
end

function game:buy_mall_items(chairid, args)
    INFO("buy_mall_items")
    local mall_id, mall_count, price_type = args.mall_id, args.mall_count, args.price_type
    if not mall_id or not mall_count or not price_type then
        return
    end

    local mall_instance = shopconfig[mall_id]
    local result = self:caculate_buy_result(chairid, price_type, mall_instance, mall_count)
    
    if result == 0 then
        --扣除对应财富，计入对应道具
        self:consume_user_wealth(chairid, price_type, -mall_instance.price * mall_count, '购买' .. mall_instance.instance_name)
        for _, package in pairs(mall_instance.packages) do
            if package.item.item_type == 'counter' then
                self._players[chairid]:modify_item_count(package.item.item_id, package.count)
            elseif package.item.item_type == 'timer' then
                self._players[chairid]:modify_item_expire(package.item.item_id, package.count * package.item.expire_time)
            end
        end
    end

    self:send_to_chair(chairid, 'buy_mall_items', {
        result = result
    })
end

function game:caculate_buy_result(chairid, wealth_type, mall_instance, mall_count)
    local result = 0
    if not mall_instance then
       return 1
    end
    local price = mall_count * mall_instance.price
    if self:get_user_wealth(chairid, wealth_type) < price then
        result = 2
    end
    return result
end

function game:get_user_wealth(chairid, wealth_type)
    if wealth_type == 'hb' then
        return self._players[chairid]:get_hb()
    end
    if wealth_type == 'wealth' then
        return self._players[chairid]:get_wealth()
    end
    if wealth_type == 'gold' then
        return self._players[chairid]:get_kb()
    end
end

function game:consume_user_wealth(chairid, wealth_type, diff, reason)
    if wealth_type == 'hb' then
        self._players[chairid]:update_hb_diff(diff)
    end
    if wealth_type == 'wealth' then
        self._players[chairid]:update_wealth_diff(diff)
    end
    if wealth_type == 'gold' then
        self._players[chairid]:wconsume_kb(-diff, reason)
    end
end

function game:open_treasure_box(chairid, args)
    INFO('open_treasure_box')
    local treasure_type, treasure_count, rare_type = args.treasure_type, args.treasure_count, args.rare_type
    
    if not treasure_type or not treasure_count or not rare_type then
        return
    end

    if treasure_count < 1 or treasure_count > 10 then
        return
    end

    local user = self._players[chairid]
    local result = self._treasure_controller:check_user_item(user, treasure_type, rare_type, treasure_count)
    local treasures = {}
    if result == 0  then
       for i = 1 , treasure_count do
            local treasure = self._treasure_controller:get_treasure(treasure_type, rare_type)
            treasures[#treasures + 1] = treasure.item_id
            user:modify_item_count(treasure.item_id, 1)
       end
       user:modify_item_count(treasureconfig[treasure_type][rare_type].needed, -treasure_count)
    end
    
    self:send_to_chair(chairid, 'open_treasure_box',{
         result = result,
         treasures = treasures
    })
end

function game:init_final()
    self._player = self._players[0]
    self._game_record = game_record:new(self._game_handle)
    self._treasure_controller = treasure_controller:new(self._game_handle)

    self._last_enter_game_time = skynet.time()
    self._last_exit_game_time = self._player:get_game_ext_data("last_exit_game_time") or self._last_enter_game_time
    local during_time = self._last_enter_game_time - self._last_exit_game_time
    self._last_enter_day = os.date("%d", os.time())
    self._last_exit_day = self._player:get_game_ext_data("last_exit_game_day") or self._last_enter_day

    self._moritx_user = {}
    local moritx_user_data_str = self._player:get_game_ext_data("moritx_user_data")
    if moritx_user_data_str then
        local data_t = cjson.decode(moritx_user_data_str)
        self._moritx_user = moritx_user:new(self._game_handle, data_t)
    else
        local data_t = {
            moritx_user_level = 0,
            moritx_user_exp = 0,
            moritx_user_fuel = 20,
        }
        self._moritx_user = moritx_user:new(self._game_handle, data_t)

        moritx_user_data_str = cjson.encode(data_t)
        self._player:set_game_ext_data({ moritx_user_data = moritx_user_data_str })
    end

    self._best_history = self._player:get_game_ext_data("best_history") or 1

    local role_data_str = self._player:get_game_ext_data("role_data")
    if role_data_str then
        INFO("get role_data_str", role_data_str)
        local data_t = cjson.decode(role_data_str)
        self._role = role:new(self._game_handle, data_t)
    end

    local game_stage_data_str = self._player:get_game_ext_data("game_stage_data")
    INFO("game_stage_data_str", game_stage_data_str)
    if game_stage_data_str then
        local data_t = cjson.decode(game_stage_data_str)
        self._game_stage = game_stage:new(self._game_handle, data_t)
    end

    self._is_combat = self._game_stage and true or false
    INFO("is_combat", self._is_combat)

    self._is_init_finish = true
end

function game:handle_player_offline(chairid)
    INFO("offline")
    self:game_end()
    self:remove_player(chairid)
    self:send_to_all("offline", {})
end

function game:handle_player_left(chairid)
    INFO("leftgame")
    self:game_end()
    self:remove_player(chairid)
    self:send_to_all("left_game", {})
end

function game:safe_exit()
    INFO("safe_exit")
    self:game_end()
    for chairid, _ in pairs(self._players) do
        self:remove_player(chairid)
    end
end

function game:get_game_name()
    return "moritx"
end

function game:update_best_history(history)
    if history > self._best_history then
        self._best_history = history
    end
end

function game:game_end()
    if not self._is_init_finish then
        return
    end

    if self._game_stage then
        self._game_stage:finish_cur_level()
        INFO("save_level", self._game_stage._cur_level)
    end

    local ext_data = {
        best_history = self._best_history,
        last_enter_game_time = self._last_enter_game_time,
        last_exit_game_time = skynet.time(),
        last_enter_game_day = self._last_enter_day,
        last_exit_game_day = os.date("%d", os.time()),
    }
    self._player:set_game_ext_data(ext_data)

    local moritx_user_data_str = cjson.encode(self._moritx_user:get_data_table())
    self._player:set_game_ext_data({ moritx_user_data = moritx_user_data_str })

    if self._role then
        local role_data_str = cjson.encode(self._role:get_data_table())
        INFO("save_role",role_data_str)
        self._player:set_game_ext_data({ role_data = role_data_str })
    else
        self._player:delete_game_ext_data("role_data")
    end

    if self._game_stage then
        local game_stage_data_str = cjson.encode(self._game_stage:get_data_table())
        self._player:set_game_ext_data({ game_stage_data = game_stage_data_str })
    else
        self._player:delete_game_ext_data("game_stage_data")
    end
end

class_helper.newservice(game, ...)