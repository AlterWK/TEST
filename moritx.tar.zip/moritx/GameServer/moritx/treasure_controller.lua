local treasure_controller = {}
local math = math

local treasureconfig = require("moritx.config.treasureconfig")
local treasuretype = treasureconfig.treasure_type
local rare_typ = treasureconfig.rare_typ
local itemconfig = require('moritx.config.itemconfig')

function treasure_controller:new(...)
    local ret = {}
    self.__index = self
    setmetatable(ret, self)
    ret:init(...)
    return ret
end

function treasure_controller:init(game)
    self._game = game
end

function treasure_controller:check_user_item(user, treasure_type, rare_type, count)
    local item = user:get_item_info(treasureconfig[treasure_type][rare_type].needed)
    return item.count >= count and 0 or 1
end

function treasure_controller:get_treasure(treasure_type, rare_typ)
    if treasure_type == treasuretype.equip then
        return self:get_equip(rare_typ)
    elseif treasure_type == treasuretype.gene then
        return self:get_gene(rare_typ)
    elseif treasure_type == treasuretype.talent then
        return self:get_talent(rare_typ)
    end
end

function treasure_controller:get_talent(rare_typ)
    INFO('start_talent')
    local talent = treasureconfig.talent[rare_typ]

    local random = math.random(0, 99)
    local genre = ''
    --查询流派
    print('genre_start', random)
    for i = 1, #talent.genre do
         if random < talent.genre[i].weight then
            genre = genre .. talent.genre[i].index
            INFO('genre:%d', random)
            break
         else
            random = random - talent.genre[i].weight   
         end
    end
    --查询天赋
    random = math.random(0, 99)
    print('item_start', random)
    for i = 1, #talent.item do
        if random < talent.item[i].weight then
           genre = genre .. string.format('%02d', talent.item[i].index)
           INFO('item:%d', random)
           break
        else
           random = random - talent.item[i].weight   
        end
   end
    --查询分支
    random = math.random(0, 99)
    print('sub_start', random)
    local sub = talent.subs[genre]
    for i = 1, #sub do
        if random < sub[i].weight then
           genre = genre .. sub[i].index
           INFO('sub:%d', random)
           break
        else
           random = random - sub[i].weight   
        end
   end
   INFO('end_open:%s', genre)
   return itemconfig[tonumber(genre)]
end

function treasure_controller:get_equip(rare_typ)
end

function treasure_controller:get_gene(rare_typ)
end

return treasure_controller
