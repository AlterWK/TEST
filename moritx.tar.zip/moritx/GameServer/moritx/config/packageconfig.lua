local itemconfig = require("moritx.config.itemconfig")

local packageconfig = {}

local function generatePackageConfig(item_id, item_count)
    local package = {}
    package.item = itemconfig[item_id]
    package.count = item_count
    return package
end

packageconfig[1] = {
    [42801001] = generatePackageConfig(42801001, 10),
    [42801002] = generatePackageConfig(42801002, 5)
}

packageconfig[428001] = {
    [4280001] = generatePackageConfig(4280001, 1)
}
packageconfig[428002] = {
    [4280001] = generatePackageConfig(4280001, 10)
}
packageconfig[428003] = {
    [4280002] = generatePackageConfig(4280002, 1)
}
packageconfig[428004] = {
    [4280002] = generatePackageConfig(4280002, 10)
}
packageconfig[428005] = {
    [4280011] = generatePackageConfig(4280011, 1)
}
packageconfig[428006] = {
    [4280011] = generatePackageConfig(4280011, 10)
}
packageconfig[428007] = {
    [4280012] = generatePackageConfig(4280012, 1)
}
packageconfig[428008] = {
    [4280012] = generatePackageConfig(4280012, 10)
}
packageconfig[428009] = {
    [4280021] = generatePackageConfig(4280021, 1)
}
packageconfig[428010] = {
    [4280021] = generatePackageConfig(4280021, 10)
}
packageconfig[428011] = {
    [4280022] = generatePackageConfig(4280022, 1)
}
packageconfig[428012] = {
    [4280022] = generatePackageConfig(4280022, 10)
}

return packageconfig
