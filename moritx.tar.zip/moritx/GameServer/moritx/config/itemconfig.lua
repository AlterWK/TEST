local itemconfig = {}

local item_type = {
    ["counter"] = 'counter',
    ["timer"] = 'timer',--以小时为单位
}

local function generateItemConfig(item_id, item_name, item_type, expire_time)
    local item = {}
    item.item_id = item_id
    item.item_name = item_name
    item.item_type = item_type
    expire_time = math.max(0, expire_time)
    item.expire_time = item_type == "timer" and expire_time or 0
    return item
end

--英雄
itemconfig[42801] = generateItemConfig(42801, '桑吉', 'counter', 0)
itemconfig[42802] = generateItemConfig(42802, '莉娜', 'counter', 0)

--宝箱
itemconfig[4280001] = generateItemConfig(4280001, '基因天赋宝箱（普通）', 'counter', 0)
itemconfig[4280002] = generateItemConfig(4280002, '基因天赋宝箱（传奇）', 'counter', 0)
itemconfig[4280011] = generateItemConfig(4280011, '装备宝箱（普通）', 'counter', 0)
itemconfig[4280012] = generateItemConfig(4280012, '装备宝箱（传奇）', 'counter', 0)
itemconfig[4280021] = generateItemConfig(4280021, '材料宝箱（普通）', 'counter', 0)
itemconfig[4280023] = generateItemConfig(4280022, '材料宝箱（传奇）', 'counter', 0)

--天赋
itemconfig[42801001] = generateItemConfig(42801001, "伺机待发（普通）", "counter", 0)
itemconfig[42801002] = generateItemConfig(42801002, "伺机待发（优秀）", "counter", 0)
itemconfig[42801003] = generateItemConfig(42801003, "伺机待发（精良）", "counter", 0)
itemconfig[42801004] = generateItemConfig(42801004, "伺机待发（史诗）", "counter", 0)
itemconfig[42801005] = generateItemConfig(42801005, "伺机待发（传说）", "counter", 0)
itemconfig[42801006] = generateItemConfig(42801006, "伺机待发（钻石）", "counter", 0)

itemconfig[42802001] = generateItemConfig(42802001, "全神贯注（普通）", "counter", 0)
itemconfig[42802002] = generateItemConfig(42802002, "全神贯注（优秀）", "counter", 0)
itemconfig[42802003] = generateItemConfig(42802003, "全神贯注（精良）", "counter", 0)
itemconfig[42802004] = generateItemConfig(42802004, "全神贯注（史诗）", "counter", 0)
itemconfig[42802005] = generateItemConfig(42802005, "全神贯注（传说）", "counter", 0)
itemconfig[42802006] = generateItemConfig(42802006, "全神贯注（钻石）", "counter", 0)

itemconfig[42801011] = generateItemConfig(42801011, "汲魂痛击（普通）", "counter", 0)
itemconfig[42801012] = generateItemConfig(42801012, "汲魂痛击（优秀）", "counter", 0)
itemconfig[42801013] = generateItemConfig(42801013, "汲魂痛击（精良）", "counter", 0)
itemconfig[42801014] = generateItemConfig(42801014, "汲魂痛击（史诗）", "counter", 0)
itemconfig[42801015] = generateItemConfig(42801015, "汲魂痛击（传说）", "counter", 0)
itemconfig[42801016] = generateItemConfig(42801016, "汲魂痛击（钻石）", "counter", 0)

itemconfig[42802011] = generateItemConfig(42802011, "弹夹改装（普通）", "counter", 0)
itemconfig[42802012] = generateItemConfig(42802012, "弹夹改装（优秀）", "counter", 0)
itemconfig[42802013] = generateItemConfig(42802013, "弹夹改装（精良）", "counter", 0)
itemconfig[42802014] = generateItemConfig(42802014, "弹夹改装（史诗）", "counter", 0)
itemconfig[42802015] = generateItemConfig(42802015, "弹夹改装（传说）", "counter", 0)
itemconfig[42802016] = generateItemConfig(42802016, "弹夹改装（钻石）", "counter", 0)

itemconfig[42801021] = generateItemConfig(42801021, "战争补给（普通）", "counter", 0)
itemconfig[42801022] = generateItemConfig(42801022, "战争补给（优秀）", "counter", 0)
itemconfig[42801023] = generateItemConfig(42801023, "战争补给（精良）", "counter", 0)
itemconfig[42801024] = generateItemConfig(42801024, "战争补给（史诗）", "counter", 0)
itemconfig[42801025] = generateItemConfig(42801025, "战争补给（传说）", "counter", 0)
itemconfig[42801026] = generateItemConfig(42801026, "战争补给（钻石）", "counter", 0)

itemconfig[42802021] = generateItemConfig(42802021, "诸神黄昏（普通）", "counter", 0)
itemconfig[42802022] = generateItemConfig(42802022, "诸神黄昏（优秀）", "counter", 0)
itemconfig[42802023] = generateItemConfig(42802023, "诸神黄昏（精良）", "counter", 0)
itemconfig[42802024] = generateItemConfig(42802024, "诸神黄昏（史诗）", "counter", 0)
itemconfig[42802025] = generateItemConfig(42802025, "诸神黄昏（传说）", "counter", 0)
itemconfig[42802026] = generateItemConfig(42802026, "诸神黄昏（钻石）", "counter", 0)

itemconfig[42801031] = generateItemConfig(42801031, "吞噬灵魂（普通）", "counter", 0)
itemconfig[42801032] = generateItemConfig(42801032, "吞噬灵魂（优秀）", "counter", 0)
itemconfig[42801033] = generateItemConfig(42801033, "吞噬灵魂（精良）", "counter", 0)
itemconfig[42801034] = generateItemConfig(42801034, "吞噬灵魂（史诗）", "counter", 0)
itemconfig[42801035] = generateItemConfig(42801035, "吞噬灵魂（传说）", "counter", 0)
itemconfig[42801036] = generateItemConfig(42801036, "吞噬灵魂（钻石）", "counter", 0)

itemconfig[42802031] = generateItemConfig(42802031, "乘胜追击（普通）", "counter", 0)
itemconfig[42802032] = generateItemConfig(42802032, "乘胜追击（优秀）", "counter", 0)
itemconfig[42802033] = generateItemConfig(42802033, "乘胜追击（精良）", "counter", 0)
itemconfig[42802034] = generateItemConfig(42802034, "乘胜追击（史诗）", "counter", 0)
itemconfig[42802035] = generateItemConfig(42802035, "乘胜追击（传说）", "counter", 0)
itemconfig[42802036] = generateItemConfig(42802036, "乘胜追击（钻石）", "counter", 0)

itemconfig[42801041] = generateItemConfig(42801041, "肾上腺素（普通）", "counter", 0)
itemconfig[42801042] = generateItemConfig(42801042, "肾上腺素（优秀）", "counter", 0)
itemconfig[42801043] = generateItemConfig(42801043, "肾上腺素（精良）", "counter", 0)
itemconfig[42801044] = generateItemConfig(42801044, "肾上腺素（史诗）", "counter", 0)
itemconfig[42801045] = generateItemConfig(42801045, "肾上腺素（传说）", "counter", 0)
itemconfig[42801046] = generateItemConfig(42801046, "肾上腺素（钻石）", "counter", 0)

itemconfig[42802041] = generateItemConfig(42802041, "嗜血本能（普通）", "counter", 0)
itemconfig[42802042] = generateItemConfig(42802042, "嗜血本能（优秀）", "counter", 0)
itemconfig[42802043] = generateItemConfig(42802043, "嗜血本能（精良）", "counter", 0)
itemconfig[42802044] = generateItemConfig(42802044, "嗜血本能（史诗）", "counter", 0)
itemconfig[42802045] = generateItemConfig(42802045, "嗜血本能（传说）", "counter", 0)
itemconfig[42802046] = generateItemConfig(42802046, "嗜血本能（钻石）", "counter", 0)

itemconfig[42801051] = generateItemConfig(42801051, "大步流星（普通）", "counter", 0)
itemconfig[42801052] = generateItemConfig(42801052, "大步流星（优秀）", "counter", 0)
itemconfig[42801053] = generateItemConfig(42801053, "大步流星（精良）", "counter", 0)
itemconfig[42801054] = generateItemConfig(42801054, "大步流星（史诗）", "counter", 0)
itemconfig[42801055] = generateItemConfig(42801055, "大步流星（传说）", "counter", 0)
itemconfig[42801056] = generateItemConfig(42801056, "大步流星（钻石）", "counter", 0)

itemconfig[42802051] = generateItemConfig(42802051, "枪林弹雨（普通）", "counter", 0)
itemconfig[42802052] = generateItemConfig(42802052, "枪林弹雨（优秀）", "counter", 0)
itemconfig[42802053] = generateItemConfig(42802053, "枪林弹雨（精良）", "counter", 0)
itemconfig[42802054] = generateItemConfig(42802054, "枪林弹雨（史诗）", "counter", 0)
itemconfig[42802055] = generateItemConfig(42802055, "枪林弹雨（传说）", "counter", 0)
itemconfig[42802056] = generateItemConfig(42802056, "枪林弹雨（钻石）", "counter", 0)

return itemconfig
