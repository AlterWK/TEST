local treasure_type = {
    equip = "equip",
    gene = "gene",
    talent = "talent"
}

local rare_type = {
    normal = "normal",
    rare = "rare"
}

local equip = {}
local gene = {}
local talent = {}

local function generateSingleOdds(sub_odds)
    local odds = {}
    for i = 1, #sub_odds do
        odds[#odds + 1] = {index = i, weight = sub_odds[i]}
    end
    return odds
end

talent.normal = {
    needed = 4280001,
    genre = {
        {
            index = 42801,
            weight = 50
        },
        {
            index = 42802,
            weight = 50
        }
    },
    item = {
        {index = 00, weight = 20},
        {index = 01, weight = 20},
        {index = 02, weight = 20},
        {index = 03, weight = 20},
        {index = 04, weight = 10},
        {index = 05, weight = 10}
    },
    subs = {
        ["4280100"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280101"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280102"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280103"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280104"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280105"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),

        ["4280200"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280201"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280202"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280203"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280204"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280205"] = generateSingleOdds({5, 10, 15, 20, 25, 25})
    }
}

talent.rare = {
    needed = 4280002,
    genre = {
        {
            index = 42801,
            weight = 50
        },
        {
            index = 42802,
            weight = 50
        }
    },
    item = {
        {index = 00, weight = 20},
        {index = 01, weight = 20},
        {index = 02, weight = 20},
        {index = 03, weight = 20},
        {index = 04, weight = 10},
        {index = 05, weight = 10}
    },
    subs = {
        ["4280100"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280101"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280102"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280103"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280104"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280105"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280200"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280201"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280202"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280203"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280204"] = generateSingleOdds({5, 10, 15, 20, 25, 25}),
        ["4280205"] = generateSingleOdds({5, 10, 15, 20, 25, 25})
    }
}

local treasureconfig = {}

treasureconfig.equip = equip
treasureconfig.gene = gene
treasureconfig.talent = talent
treasureconfig.treasure_type = treasure_type
treasureconfig.rare_type = rare_type

return treasureconfig
