local packageconfig = require("moritx.config.packageconfig")

local shopconfig = {}

local function generateShopConfig(instance_id, instance_name, price, price_type, packages)
    local instance = {}
    instance.instance_id = instance_id
    instance.instance_name = instance_name
    instance.price = price
    instance.price_type = price_type
    instance.packages = packages
    return instance
end

shopconfig[428001] = generateShopConfig(428001, "基因天赋宝箱（普通）x1", 10, "wealth", packageconfig[428001])
shopconfig[428002] = generateShopConfig(428002, "基因天赋宝箱（普通）x10", 10, "wealth", packageconfig[428002])
shopconfig[428003] = generateShopConfig(428003, "基因天赋宝箱（传奇）x1", 10, "wealth", packageconfig[428003])
shopconfig[428004] = generateShopConfig(428004, "基因天赋宝箱（传奇）x10", 10, "wealth", packageconfig[428004])
shopconfig[428005] = generateShopConfig(428005, "装备宝箱（普通）x1", 10, "wealth", packageconfig[428005])
shopconfig[428006] = generateShopConfig(428006, "装备宝箱（普通）x10", 10, "wealth", packageconfig[428006])
shopconfig[428007] = generateShopConfig(428007, "装备宝箱（传奇）x1", 10, "wealth", packageconfig[428007])
shopconfig[428008] = generateShopConfig(428008, "装备宝箱（传奇）x10", 10, "wealth", packageconfig[428008])
shopconfig[428009] = generateShopConfig(428009, "材料宝箱（普通）x1", 10, "wealth", packageconfig[428009])
shopconfig[428010] = generateShopConfig(428010, "材料宝箱（普通）x10", 10, "wealth", packageconfig[428010])
shopconfig[428011] = generateShopConfig(428011, "材料宝箱（传奇）x1", 10, "wealth", packageconfig[428011])
shopconfig[428012] = generateShopConfig(428012, "材料宝箱（传奇）x10", 10, "wealth", packageconfig[428012])


return shopconfig
