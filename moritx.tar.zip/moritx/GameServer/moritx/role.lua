local skynet = require("skynet")
local skynet_call = skynet.call
local class_helper = require("helper.class_helper")
local role = class_helper.class("role")

local INFO = INFO

function role:new(...)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o:init(...)
    return o
end

function role:init(game, data)
    self._game = game
    self._index = data.index or 0
    self._level = data.level or 0
    INFO("cur_health", data.cur_health)
    INFO("cur_armor", data.cur_armor)
    self._cur_health = data.cur_health or 0
    self._cur_armor = data.cur_armor or 0
    self._mods = data.mods or {}
    self._loots = data.loots or {}
end

function role:update_cur_state(data)
    INFO("cur_health", data.cur_health)
    INFO("cur_armor", data.cur_armor)
    self._cur_health = data.cur_health
    self._cur_armor = data.cur_armor
end

function role:add_mods(add_mods)
    if add_mods then
        for _, mod in pairs(add_mods) do
            table.insert(self._mods, mod)
        end
    end
end

function role:add_loots(add_loots)
    if add_loots then
        for _, loot in pairs(add_loots) do
            table.insert(self._loots, loot)
        end
    end
end

function role:get_data_table()
    local t = {
        index = self._index,
        level = self._level,
        cur_health = self._cur_health,
        cur_armor = self._cur_armor,
    }
    if #self._mods > 0 then
        t.mods = self._mods
    end

    if #self._loots > 0 then
        t.loots = self._loots
    end

    return t
end

return role